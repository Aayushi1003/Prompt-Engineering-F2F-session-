# AI Teacher Challenge Hub

A live leaderboard, game rules, team boards, prompt wall, exit ticket, resources page and AI judge for the **Prompt Engineering for Educators** workshop (45 minutes, IB trainee teachers).

- **Front end:** `index.html`, hosted free on GitHub Pages.
- **Back end:** `apps-script/Code.gs`, a Google Apps Script attached to your own Google Sheet. Every team, score, prompt and exit ticket is saved there, and the Sheet downloads as Excel.
- **AI judge:** automatic if you add a free Gemini API key to the script; otherwise it shows a ready-made judging prompt to copy into Claude, ChatGPT or Gemini, and you paste the reply back.

**Participants need nothing:** no Google account, no Claude account, no sign-in. They open the link or scan the QR code and play. Only you (the facilitator) sign in, once, while setting up.

Setup takes about 15 minutes. Do it at least a day before the session.

---

## Part 1: Create the back end (Google Sheet + Apps Script)

> **Use a personal Gmail account for this.** School Google Workspace accounts often have an admin setting that hides the "Anyone" access option (see Part 2). If you only have a school account, try it; if "Anyone" is missing, switch to a personal Gmail.

1. Go to [sheets.new](https://sheets.new) and name the sheet **AI Teacher Challenge Hub data**.
2. Click **Extensions → Apps Script**.
3. Delete the sample code, paste in everything from `apps-script/Code.gs`, and click **Save** (disk icon).
4. In the function dropdown at the top, choose **selfTest** and click **Run**.
   - Google asks for permission: **Review permissions** → choose your account → **Advanced** → **Go to project (unsafe)** → **Allow**. It says "unsafe" only because you wrote the script yourself and Google hasn't reviewed it. Only you see this screen; participants never do.
5. Open **Execution log** at the bottom. You should see:
   - `Your facilitator PIN is: ######` (write it down)
   - `Read test: OK` and `Backend is ready.`
6. To change the PIN: **Project Settings** (gear icon) → **Script properties** → edit `FACILITATOR_PIN`.
7. *(Optional, for automatic AI judging)* Get a free API key at [aistudio.google.com/apikey](https://aistudio.google.com/apikey). In **Script properties**, click **Add script property**: name `GEMINI_API_KEY`, value = your key. Never put this key in `index.html`.

## Part 2: Deploy so it works for every participant

This is the step that decides whether participants can use it. Follow it exactly.

1. In the Apps Script editor, click **Deploy → New deployment**.
2. Click the gear next to **Select type** → **Web app**.
3. Fill in:
   - **Description:** `Workshop Hub v1`
   - **Execute as:** **Me (your-email@gmail.com)**. The script runs with your permission, so participants don't need access to your Sheet, and the Sheet stays private.
   - **Who has access:** **Anyone**. Not "Anyone with Google account", and not "Only myself". "Anyone" means anyone with the link, even without signing in.
4. Click **Deploy**, then **Authorize access** if asked (same steps as Part 1).
5. Copy the **Web app URL**. Check it:
   - It starts with `https://script.google.com/macros/s/`
   - It ends with **`/exec`** (not `/dev`: the `/dev` link only works for you)

### Test it like a participant (2 minutes)

1. Open a **private / incognito window** (so you're signed out of Google).
2. Paste the Web app URL and press Enter.
3. You should see: `{"ok":true,"message":"AI Teacher Challenge Hub backend is running."}`
   - **Sign-in page or "You need access"**: access isn't set to **Anyone**. Fix it in Part 2, step 3, then redeploy (see "Changing anything later").
   - **"Sorry, unable to open the file at this time"**: you copied a `/dev` link, or the deployment was archived. Use the `/exec` link from **Deploy → Manage deployments**.
   - **"Anyone" isn't in the list**: your school Workspace admin has blocked public web apps. Redo Parts 1–2 with a personal Gmail account.

## Part 3: Connect the page

1. Open `index.html` in any text editor (or on GitHub, after upload, with the pencil icon).
2. Near the top of the first `<script>` block, find:
   ```js
   API_URL: 'PASTE_YOUR_WEB_APP_URL_HERE',
   ```
3. Replace the placeholder with your `/exec` Web app URL, keeping the quotes. Save.

## Part 4: Host it on GitHub Pages

1. On [github.com](https://github.com), click **+ → New repository**. Name it e.g. `ai-teacher-challenge`, set it to **Public**, tick **Add a README file**, and click **Create repository**.
2. Click **Add file → Upload files**, drag in `index.html` **and the whole `pdfs` folder** (and this `README.md` and the `apps-script` folder if you like), then **Commit changes**. Dragging the folder keeps the `pdfs/` path, which the Resources tiles need.
3. Go to **Settings → Pages**. Under **Build and deployment**, set **Source: Deploy from a branch**, **Branch: main**, folder **/ (root)**, and click **Save**.
4. Wait 1–2 minutes and refresh. Your site appears at
   `https://YOUR-USERNAME.github.io/ai-teacher-challenge/`
5. The exit ticket link for your slides is the same address with `#exit` on the end.

## Part 5: Full rehearsal with "participants"

Do this with two or three devices, ideally **on the school Wi-Fi you'll use in the session**.

1. **Phone, signed out of Google, in a private tab:** open the site. The badge at the top says **Live**.
2. On the phone: **Team boards** → create a team → add a role. Within about 5 seconds it appears on your laptop.
3. On a second phone: post a prompt on the **Prompt wall** and submit an **Exit ticket**.
4. On your laptop: click **Facilitator login**, enter your PIN. The **Facilitator** tab appears, the test ticket is listed, and the Leaderboard score boxes become editable. Type a score and watch it appear on the phones.
5. Open your Google Sheet: you'll see a `docs` tab (raw data) and an **Exit tickets** tab (readable).
6. Clean up: delete the test rows in both tabs.

If the phones show **Not connected** or saves fail, see Troubleshooting.

## Running the session

| Moment | What to do |
| --- | --- |
| Kick-off | Show the site's QR code; teams create themselves on **Team boards** (or you add them on the **Leaderboard**). Point everyone to the **Rules** tab. |
| After each round | Type each team's points into the Leaderboard. Everyone sees the podium update. |
| After Round 2 pitches | **Facilitator → Judge Prompt Battle**. With a Gemini key it scores automatically; without one, copy each prompt into your chatbot and paste the reply back. Review, then **Apply**. |
| End | Participants submit the **Exit ticket**. Then press **AI session review** and **Download Excel (.xlsx)**. |

## Troubleshooting

| What you see | Why | Fix |
| --- | --- | --- |
| Badge says **Not connected** for everyone | `API_URL` in `index.html` is still the placeholder, or has a typo | Paste the `/exec` URL again (Part 3), commit, wait 1 minute, refresh |
| Works for you, **not for participants** | Access is "Only myself" or "Anyone with Google account", or you used the `/dev` link | Part 2, step 3: set **Anyone**, redeploy, use the `/exec` link |
| Works on mobile data, **not on school Wi-Fi** | The school network blocks `script.google.com` or `github.io` | Ask IT to allow both, or have participants use mobile data / a hotspot |
| "Couldn't save" now and then with a big group | Too many saves at the same second; the page retries automatically | Wait a moment and press save again. For more than about 40 people, change `POLL_MS` to `10000` in `index.html` |
| Facilitator tab doesn't appear | Wrong PIN, or extra spaces | Click **Log out**, then **Facilitator login** again; check the PIN in Script properties |
| Changes to `Code.gs` don't take effect | Old version still deployed | Redeploy as a new version (below) |
| AI Judge always shows copy-paste | No `GEMINI_API_KEY`, or the key/model is invalid | Add or fix the key in Script properties; check the Executions log for the error |

## Changing anything later

- **Changed `Code.gs`:** **Deploy → Manage deployments → ✏️ (Edit) → Version: New version → Deploy**. The `/exec` URL stays the same, so nothing else changes. (Creating a *New deployment* instead gives a new URL that you'd have to paste into `index.html` again.)
- **Changed `index.html`:** upload it to GitHub again; the site updates within a minute or two.
- **Changed the PIN:** edit it in Script properties; no redeploy needed.

## Good to know

- **Updates are near-live:** every open page checks for changes every 5 seconds.
- **Capacity:** the script runs as you, and Google allows **30 simultaneous executions per user** for Apps Script. Each check takes a fraction of a second and the script caches results for a few seconds, so a room of about 40 is comfortable.
- **Privacy:** your Sheet stays private; participants can only add teams, prompts and their own exit ticket, and only you (with the PIN) can see all tickets, change scores or run the AI judge. The PIN is light protection, suitable for a workshop, not for sensitive data, so keep the rule: no student names or personal data anywhere in the Hub.
- **Your data stays in your Google Sheet.** Download it any time with **File → Download → Microsoft Excel (.xlsx)**, or use the Hub's **Download Excel** button for a tidier workbook with the AI judging included.
- **Gemini model:** the script uses `gemini-3.8-flash`. If Google renames models, add a script property `GEMINI_MODEL` with the new name.
