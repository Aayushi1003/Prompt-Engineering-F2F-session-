/**
 * AI Teacher Challenge Hub: Google Apps Script backend
 * ----------------------------------------------------
 * Stores the Hub's teams, scores, prompts, exit tickets and AI judging
 * in this Google Sheet, and (optionally) calls Gemini for the AI Judge.
 *
 * Setup (full steps in README.md):
 *  1. Paste this file into Extensions > Apps Script of a new Google Sheet.
 *  2. Run setup() once and read your facilitator PIN in the execution log.
 *  3. Deploy > New deployment > Web app (Execute as: Me, Access: Anyone).
 *  4. Paste the web app URL into CONFIG.API_URL in index.html.
 *
 * Script properties (Project Settings > Script properties):
 *  FACILITATOR_PIN  required. Unlocks scores, judging and exit tickets.
 *  GEMINI_API_KEY   optional. Turns on automatic AI judging.
 *  GEMINI_MODEL     optional. Defaults to gemini-3.8-flash.
 */

const DOC_SHEET = 'docs';
const PUBLIC_COLLECTIONS = ['teams', 'scores', 'prompts'];
const OPEN_WRITE_COLLECTIONS = ['teams', 'prompts'];
const PATH_RE = /^[A-Za-z0-9_-]+\/[A-Za-z0-9_.:-]+$/;
const MAX_DOC_CHARS = 45000;

function setup() {
  docSheet_();
  const p = props_();
  if (!p.getProperty('FACILITATOR_PIN')) {
    p.setProperty('FACILITATOR_PIN', String(Math.floor(100000 + Math.random() * 900000)));
  }
  Logger.log('Your facilitator PIN is: ' + p.getProperty('FACILITATOR_PIN'));
  Logger.log('Change it any time in Project Settings > Script properties.');
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.action === 'state') {
    const admin = isAdmin_(p.pin);
    const all = readAllCached_();
    const docs = {};
    Object.keys(all).forEach(path => {
      if (canRead_(path, admin, p.me)) docs[path] = all[path].data;
    });
    return json_({ docs, admin, aiEnabled: admin && !!props_().getProperty('GEMINI_API_KEY') });
  }
  return json_({ ok: true, message: 'AI Teacher Challenge Hub backend is running.' });
}

function doPost(e) {
  let b;
  try { b = JSON.parse(e.postData.contents); }
  catch (err) { return json_({ error: 'Bad request', code: 'invalid_argument' }); }
  const admin = isAdmin_(b.pin);
  try {
    if (b.action === 'set') return json_(setDoc_(String(b.path || ''), b.data, admin, b.me));
    if (b.action === 'ai') {
      if (!admin) return json_({ error: 'Facilitator only', code: 'invalid_argument' });
      return json_({ text: gemini_(String(b.prompt || '')) });
    }
    return json_({ error: 'Unknown action', code: 'invalid_argument' });
  } catch (err) {
    return json_({ error: String(err && err.message || err), code: 'unavailable' });
  }
}

/* ---------- storage ---------- */

function setDoc_(path, data, admin, me) {
  if (!PATH_RE.test(path)) return { error: 'Bad path', code: 'invalid_argument' };
  if (!canWrite_(path, admin, me)) return { error: 'Not allowed', code: 'invalid_argument' };
  const text = JSON.stringify(data || {});
  if (text.length > MAX_DOC_CHARS) return { error: 'Entry too large', code: 'invalid_argument' };
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const all = readAll_();
    const sh = docSheet_();
    const now = new Date();
    if (all[path]) sh.getRange(all[path].row, 2, 1, 2).setValues([[text, now]]);
    else sh.appendRow([path, text, now]);
    if (path.indexOf('tickets/') === 0) mirrorTicket_(path, data || {});
    CacheService.getScriptCache().remove('all');
  } finally {
    lock.releaseLock();
  }
  return { ok: true };
}

function readAll_() {
  const values = docSheet_().getDataRange().getValues();
  const out = {};
  for (let i = 1; i < values.length; i++) {
    const path = values[i][0];
    if (!path) continue;
    try { out[path] = { row: i + 1, data: JSON.parse(values[i][1]) }; } catch (err) {}
  }
  return out;
}

/* Short cache so a full room polling every few seconds stays fast */
function readAllCached_() {
  const cache = CacheService.getScriptCache();
  const hit = cache.get('all');
  if (hit) { try { return JSON.parse(hit); } catch (err) {} }
  const all = readAll_();
  const text = JSON.stringify(all);
  if (text.length < 95000) cache.put('all', text, 4);
  return all;
}

/* Run this from the editor to check everything before the session */
function selfTest() {
  setup();
  const res = setDoc_('teams/selftest', { name: 'Self-test team', created: Date.now() }, true, 'x');
  Logger.log('Write test: ' + JSON.stringify(res));
  const all = readAll_();
  Logger.log('Read test: ' + (all['teams/selftest'] ? 'OK' : 'FAILED'));
  const sh = docSheet_();
  sh.deleteRow(all['teams/selftest'].row);
  CacheService.getScriptCache().remove('all');
  Logger.log('Self-test row removed. Backend is ready.');
}

function docSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(DOC_SHEET);
  if (!sh) {
    sh = ss.insertSheet(DOC_SHEET);
    sh.appendRow(['path', 'json', 'updated']);
    sh.setFrozenRows(1);
  }
  return sh;
}

/* A readable copy of every exit ticket, for File > Download > .xlsx */
function mirrorTicket_(path, d) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const head = ['Ticket id', 'Name', 'Team', 'Subject', 'Role for AI', 'How they will check', 'Confidence', 'Question', 'Submitted'];
  let sh = ss.getSheetByName('Exit tickets');
  if (!sh) { sh = ss.insertSheet('Exit tickets'); sh.appendRow(head); sh.setFrozenRows(1); }
  const id = path.split('/')[1];
  const safe = v => (typeof v === 'string' && /^[=+\-@]/.test(v)) ? "'" + v : v;
  const row = [id, d.name, d.team, d.subject, d.role, d.check, d.confidence, d.question].map(v => safe(v == null ? '' : v));
  row.push(new Date(d.at || Date.now()));
  const ids = sh.getRange(1, 1, Math.max(sh.getLastRow(), 1), 1).getValues().map(r => r[0]);
  const i = ids.indexOf(id);
  if (i > 0) sh.getRange(i + 1, 1, 1, row.length).setValues([row]);
  else sh.appendRow(row);
}

/* ---------- access rules ---------- */

function props_() { return PropertiesService.getScriptProperties(); }

function isAdmin_(pin) {
  const real = props_().getProperty('FACILITATOR_PIN');
  return !!real && String(pin || '') === real;
}

function canRead_(path, admin, me) {
  const col = path.split('/')[0];
  if (admin) return true;
  if (PUBLIC_COLLECTIONS.indexOf(col) >= 0) return true;
  return col === 'tickets' && !!me && path === 'tickets/' + me;
}

function canWrite_(path, admin, me) {
  const col = path.split('/')[0];
  if (admin) return true;
  if (OPEN_WRITE_COLLECTIONS.indexOf(col) >= 0) return true;
  return col === 'tickets' && !!me && path === 'tickets/' + me;
}

/* ---------- optional AI judge (Gemini) ---------- */

function gemini_(prompt) {
  const key = props_().getProperty('GEMINI_API_KEY');
  if (!key) throw new Error('No GEMINI_API_KEY set');
  const model = props_().getProperty('GEMINI_MODEL') || 'gemini-3.8-flash';
  const res = UrlFetchApp.fetch('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent', {
    method: 'post',
    contentType: 'application/json',
    headers: { 'x-goog-api-key': key },
    payload: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { responseMimeType: 'application/json', temperature: 0.2 }
    }),
    muteHttpExceptions: true
  });
  const j = JSON.parse(res.getContentText());
  if (!j.candidates || !j.candidates.length) throw new Error((j.error && j.error.message) || 'AI call failed');
  return j.candidates[0].content.parts.map(p => p.text || '').join('');
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
